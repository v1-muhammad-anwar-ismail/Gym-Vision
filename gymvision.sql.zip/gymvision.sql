-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 28, 2026 at 10:12 AM
-- Server version: 8.0.30
-- PHP Version: 8.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gymvision`
--
CREATE DATABASE IF NOT EXISTS `gymvision` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `gymvision`;

-- --------------------------------------------------------

--
-- Table structure for table `ai_configs`
--

DROP TABLE IF EXISTS `ai_configs`;
CREATE TABLE `ai_configs` (
  `id` bigint UNSIGNED NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ai_configs`
--

INSERT INTO `ai_configs` (`id`, `provider`, `model`, `api_key`, `base_url`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'Google Gemini', 'gemini-2.0-flash-lite', 'AIzaSyCJAN8uyclngIaFnQnDiQRh8eYvy7SY65o', 'https://generativelanguage.googleapis.com', 1, '2026-05-27 21:04:58', '2026-05-27 22:39:57'),
(3, 'Google Gemini', 'gemini-2.0-flash', 'AIzaSyCJAN8uyclngIaFnQnDiQRh8eYvy7SY65o', 'https://generativelanguage.googleapis.com', 1, '2026-05-27 22:40:49', '2026-05-27 22:40:59'),
(4, 'Google Gemini', 'gemini-2.5-flash-preview-05-20', 'AIzaSyCJAN8uyclngIaFnQnDiQRh8eYvy7SY65o', 'https://generativelanguage.googleapis.com', 1, '2026-05-27 22:41:25', '2026-05-27 22:41:32'),
(5, 'Google Gemini', 'gemini-2.5-pro-preview-05-06', 'AIzaSyCJAN8uyclngIaFnQnDiQRh8eYvy7SY65o', 'https://generativelanguage.googleapis.com', 1, '2026-05-27 22:41:56', '2026-05-27 22:42:02'),
(6, 'Groq', 'llama-3.3-70b-versatile', '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', 'https://api.groq.com/openai/v1', 1, '2026-05-27 22:55:10', '2026-05-27 22:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `analysis_history`
--

DROP TABLE IF EXISTS `analysis_history`;
CREATE TABLE `analysis_history` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `video_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exercise_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ai_feedback` text COLLATE utf8mb4_unicode_ci,
  `score` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `analysis_history`
--

INSERT INTO `analysis_history` (`id`, `user_id`, `video_path`, `exercise_type`, `ai_feedback`, `score`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, 'Angkat Beban', 'Gemini API Error (429): Model \'gemini-2.0-flash-lite\' mungkin tidak tersedia. Coba gunakan model lain seperti \'gemini-2.0-flash\'.', 0, '2026-05-27 22:42:55', '2026-05-27 22:42:55'),
(2, 3, NULL, 'Angkat Beban', 'Gemini API Error (429): Model \'gemini-2.0-flash\' mungkin tidak tersedia. Coba gunakan model lain seperti \'gemini-2.0-flash\'.', 0, '2026-05-27 22:51:38', '2026-05-27 22:51:38'),
(3, 3, NULL, 'Angkat Beban', 'Posisi squat Anda sudah cukup dalam, lanjutkan latihan dengan semangat!', 90, '2026-05-27 22:55:54', '2026-05-27 22:55:54'),
(4, 3, NULL, 'Angkat Beban', 'Latihan Angkat Beban Anda menunjukkan kemiringan bahu yang cukup besar, terutama pada bahu kiri dengan ROM 176,5°. Pergerakan lutut kanan Anda juga lebih luas dibandingkan dengan lutut kiri, yang menunjukkan asimetri gerakan. Perlu diperhatikan untuk menjaga keseimbangan dan menghindari cedera. Dengan sedikit penyesuaian, Anda dapat meningkatkan teknik Anda.', 80, '2026-05-27 23:05:39', '2026-05-27 23:05:39'),
(5, 3, NULL, 'Angkat Beban', 'Gerakan angkat beban Anda cukup baik, namun perlu diperhatikan agar gerakan kedua sisi tubuh lebih simetris, terutama pada bagian bahu dan siku. Pastikan Anda menjaga punggung tetap lurus dan turunkan beban hingga posisi yang lebih rendah. Dengan sedikit penyesuaian, Anda bisa meningkatkan kualitas gerakan Anda.', 80, '2026-05-27 23:17:57', '2026-05-27 23:17:57'),
(6, 3, NULL, 'Angkat Beban', 'Your Angkat Beban movement looks good, but there\'s a noticeable difference in the range of motion between your left and right sides, so focus on keeping both arms and legs moving in sync. To improve, try to lower the dumbbells a bit further and keep your back straight throughout the entire motion. Also, ensure that both hips and knees are bending evenly, which will help you maintain balance and generate more power. Keep up the good work and make those adjustments for an even stronger next set!', 80, '2026-05-27 23:36:08', '2026-05-27 23:36:08'),
(7, 3, NULL, 'Angkat Beban', 'Gerakan Angkat Beban Anda sudah cukup baik, namun perlu sedikit penyesuaian agar lebih seimbang dan efektif. Pastikan Anda untuk menurunkan beban hingga posisi yang lebih rendah dan menjaga kedua lengan bergerak dengan kecepatan yang sama. Dengan sedikit penyesuaian, Anda akan dapat meningkatkan hasil latihan Anda.', 80, '2026-05-27 23:37:07', '2026-05-27 23:37:07');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exercise_types`
--

DROP TABLE IF EXISTS `exercise_types`;
CREATE TABLE `exercise_types` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_histories`
--

DROP TABLE IF EXISTS `login_histories`;
CREATE TABLE `login_histories` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `logged_in_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_histories`
--

INSERT INTO `login_histories` (`id`, `user_id`, `ip_address`, `device`, `city`, `country`, `latitude`, `longitude`, `logged_in_at`, `created_at`, `updated_at`) VALUES
(6, 3, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36', 'Pasuruan', 'Indonesia', -7.6459000, 112.9074000, '2026-05-27 20:12:21', '2026-05-27 20:12:21', '2026-05-27 20:12:21'),
(7, 3, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36', 'Pasuruan', 'Indonesia', -7.6459000, 112.9074000, '2026-05-27 20:33:15', '2026-05-27 20:33:15', '2026-05-27 20:33:15'),
(8, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Surabaya', 'Indonesia', -7.2594000, 112.7860000, '2026-05-28 00:55:13', '2026-05-28 00:55:13', '2026-05-28 00:55:13'),
(9, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Surabaya', 'Indonesia', -7.2594000, 112.7860000, '2026-05-28 00:55:48', '2026-05-28 00:55:48', '2026-05-28 00:55:48');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_05_27_032116_create_exercise_types_table', 1),
(5, '2026_05_27_032117_create_analysis_history_table', 1),
(6, '2026_05_27_054922_create_ai_configs_table', 1),
(7, '2026_05_27_055828_create_personal_access_tokens_table', 2),
(8, '2026_05_27_102353_create_otps_table', 3),
(9, '2026_05_27_132600_add_profile_and_admin_fields_to_users_table', 4),
(10, '2026_05_27_132612_create_login_histories_table', 4),
(11, '2026_05_28_035100_add_base_url_and_is_active_to_ai_configs_table', 5),
(12, '2026_05_28_053300_make_video_path_nullable_in_analysis_history', 6);

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

DROP TABLE IF EXISTS `otps`;
CREATE TABLE `otps` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `email`, `otp`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'v2.antigravity@gmail.com', '671028', '2026-05-27 04:05:04', '2026-05-27 04:00:04', '2026-05-27 04:00:04'),
(3, 'v1.antigravity@gmail.com', '159855', '2026-05-27 05:25:25', '2026-05-27 05:20:25', '2026-05-27 05:20:25');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'auth-token', 'bff4aae1871748fe9c06cc05c0eee10f5b26e363b832fe20104a24baed22b9d1', '[\"*\"]', '2026-05-27 06:36:30', NULL, '2026-05-27 05:37:36', '2026-05-27 06:36:30'),
(2, 'App\\Models\\User', 2, 'auth-token', '471d267946845364460943798af64418601d5a0ac043f48f75d978519d590055', '[\"*\"]', '2026-05-27 06:52:36', NULL, '2026-05-27 06:39:32', '2026-05-27 06:52:36'),
(3, 'App\\Models\\User', 3, 'auth-token', '9787a5bcc18a09a984eeea7b677f33dbaf1d054df15567e819618fcf87a083fa', '[\"*\"]', NULL, NULL, '2026-05-27 06:54:21', '2026-05-27 06:54:21'),
(4, 'App\\Models\\User', 3, 'auth-token', '4676b7252aa7db60717aeb5c10d4693c979d55058e9e39675a9ae85239eb09f2', '[\"*\"]', '2026-05-27 08:09:34', NULL, '2026-05-27 06:54:36', '2026-05-27 08:09:34'),
(5, 'App\\Models\\User', 3, 'auth-token', '9015f2e674ff6bc1dcc081735ac2748def00d38b70e54e60c181f90a4bbb4826', '[\"*\"]', '2026-05-27 08:13:55', NULL, '2026-05-27 08:13:18', '2026-05-27 08:13:55'),
(6, 'App\\Models\\User', 3, 'auth-token', '1418e4675821ce14f17f42503cfbf341a854065e001af4d1cb44f0a3df4e5a15', '[\"*\"]', '2026-05-27 08:23:55', NULL, '2026-05-27 08:14:05', '2026-05-27 08:23:55'),
(7, 'App\\Models\\User', 3, 'auth-token', 'a5471771fd962db322ab6739b5b0d8101fe9dbc3c499862d1e476db79e4b3757', '[\"*\"]', '2026-05-27 08:28:31', NULL, '2026-05-27 08:24:05', '2026-05-27 08:28:31'),
(8, 'App\\Models\\User', 3, 'auth-token', '58ea21bb38ab4454d7f65eea81ce4ee9eeabc8a1d825e8ced68a1ab847c52897', '[\"*\"]', '2026-05-27 19:53:34', NULL, '2026-05-27 19:36:45', '2026-05-27 19:53:34'),
(9, 'App\\Models\\User', 3, 'auth-token', 'ebb4d8be8fa68b0b229a8833209875950cd67ec3f4c9491b06a821cc68ccd773', '[\"*\"]', '2026-05-27 19:59:17', NULL, '2026-05-27 19:53:33', '2026-05-27 19:59:17'),
(10, 'App\\Models\\User', 3, 'auth-token', '5fe6bdabbfc634d78fbba21554cfa240bd8c9f5a2d33c14633e41b1bf9f7fffe', '[\"*\"]', '2026-05-27 20:04:27', NULL, '2026-05-27 20:04:20', '2026-05-27 20:04:27'),
(11, 'App\\Models\\User', 3, 'auth-token', '045bb80f33b5cae86255f31940bf53dcf0b8a8605fb832756123b4a6bfa961aa', '[\"*\"]', '2026-05-27 20:12:12', NULL, '2026-05-27 20:11:13', '2026-05-27 20:12:12'),
(12, 'App\\Models\\User', 3, 'auth-token', '90d6bdcbccda5d825e9c3eaa189dd6e7a9afeb1a423a864bbeb803688b28ad99', '[\"*\"]', '2026-05-27 20:13:01', NULL, '2026-05-27 20:12:20', '2026-05-27 20:13:01'),
(13, 'App\\Models\\User', 3, 'auth-token', '7d0f6fa9f60db2dcb19e8fd2a50eb8215a02c5a7039e22481a2088a2ec25937a', '[\"*\"]', '2026-05-28 00:37:44', NULL, '2026-05-27 20:33:14', '2026-05-28 00:37:44'),
(14, 'App\\Models\\User', 3, 'auth-token', 'fe6d5795700e91b30ab2051b82f8ccf841bf54448451d0c1f2f88dc32d19fc87', '[\"*\"]', '2026-05-28 00:51:35', NULL, '2026-05-28 00:49:48', '2026-05-28 00:51:35'),
(15, 'App\\Models\\User', 3, 'auth-token', '29e07e832a0e4ce79bae9c6ff291dd709ac88c4841c6c522bbd5f4e5aff73322', '[\"*\"]', '2026-05-28 00:55:15', NULL, '2026-05-28 00:55:11', '2026-05-28 00:55:15'),
(16, 'App\\Models\\User', 3, 'auth-token', '191d68ec015c4e24775c4a02cd382466af0e250756e63dbb72b305755b3f68e5', '[\"*\"]', '2026-05-28 02:27:46', NULL, '2026-05-28 00:55:47', '2026-05-28 02:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('v6mHvG5oXCYxXu8bXhn4lOahNUNUNN0jDB28cszx', NULL, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36', 'eyJfdG9rZW4iOiJNZ1hvR083NGF5Q1BrY25mU1BZaUVsWkUxSWpPTWQzenZFS3NVTWRYIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo3MDAxXC9hdXRoXC9nb29nbGVcL2NhbGxiYWNrP2F1dGh1c2VyPTAmY29kZT00JTJGMEFlb1d1TS1zZzc3cG54ckdCNlNnaFNOdWtEclRTTERiZXZmeFA5M0l4X1JLbTdSTlcyWXpUbzFiVE9nRkZpang2dXZxUEEmaXNzPWh0dHBzJTNBJTJGJTJGYWNjb3VudHMuZ29vZ2xlLmNvbSZwcm9tcHQ9bm9uZSZzY29wZT1lbWFpbCUyMHByb2ZpbGUlMjBodHRwcyUzQSUyRiUyRnd3dy5nb29nbGVhcGlzLmNvbSUyRmF1dGglMkZ1c2VyaW5mby5lbWFpbCUyMG9wZW5pZCUyMGh0dHBzJTNBJTJGJTJGd3d3Lmdvb2dsZWFwaXMuY29tJTJGYXV0aCUyRnVzZXJpbmZvLnByb2ZpbGUmc3RhdGU9dkVaT0w2elRqbnI4S2lrT0hHcTcza0lOdThiTDYxY3VJOE5HdzJuUSIsInJvdXRlIjpudWxsfSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1779937940),
('zj4fIZYqcPK7GpcBqOdYG3zhIxqY7siZyu5swbxv', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiI3N0o1eWRMTEdNaDlLZ1pZQUhrRHhxVGoxdHV0ZmtWNm9vNmpLdld4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo3MDAxXC9hdXRoXC9nb29nbGVcL2NhbGxiYWNrP2F1dGh1c2VyPTAmY29kZT00JTJGMEFlb1d1TS1kbjU5bVNFVHZ1NHVWLTZET0RkX21tRkpySUlBeG51d0RXWng2MW40TWxibkJrYVo2R3Jmazd6WjVBcU5teGcmaXNzPWh0dHBzJTNBJTJGJTJGYWNjb3VudHMuZ29vZ2xlLmNvbSZwcm9tcHQ9bm9uZSZzY29wZT1lbWFpbCUyMHByb2ZpbGUlMjBodHRwcyUzQSUyRiUyRnd3dy5nb29nbGVhcGlzLmNvbSUyRmF1dGglMkZ1c2VyaW5mby5wcm9maWxlJTIwb3BlbmlkJTIwaHR0cHMlM0ElMkYlMkZ3d3cuZ29vZ2xlYXBpcy5jb20lMkZhdXRoJTJGdXNlcmluZm8uZW1haWwmc3RhdGU9TWI3VW1rN3EwV1VmUnZXWUNYSm9tUjIyV2hEYU1sSFRxbEw1ZDR1UCIsInJvdXRlIjpudWxsfSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==', 1779954911);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `otp_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `age`, `location`, `email_verified_at`, `password`, `google_id`, `avatar`, `role`, `is_banned`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Stan Vision', 'stanvision1534@gmail.com', 'StanVision', 20, 'Surabaya', '2026-05-27 06:54:21', '$2y$12$VFkvvdKMNPK7uFjgfCmpEO9uvMHV86SI0f80OzgXgPFJNP2zaBXUi', '101219166593606739773', 'http://localhost:7001/storage/avatars/6a170c8828ed1.webp', 'admin', 0, NULL, NULL, NULL, '2026-05-27 06:54:21', '2026-05-27 20:40:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ai_configs`
--
ALTER TABLE `ai_configs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `analysis_history`
--
ALTER TABLE `analysis_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `analysis_history_user_id_foreign` (`user_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_expiration_index` (`expiration`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_locks_expiration_index` (`expiration`);

--
-- Indexes for table `exercise_types`
--
ALTER TABLE `exercise_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  ADD KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_histories`
--
ALTER TABLE `login_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_histories_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otps_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  ADD KEY `personal_access_tokens_expires_at_index` (`expires_at`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ai_configs`
--
ALTER TABLE `ai_configs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `analysis_history`
--
ALTER TABLE `analysis_history`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `exercise_types`
--
ALTER TABLE `exercise_types`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_histories`
--
ALTER TABLE `login_histories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `analysis_history`
--
ALTER TABLE `analysis_history`
  ADD CONSTRAINT `analysis_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `login_histories`
--
ALTER TABLE `login_histories`
  ADD CONSTRAINT `login_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
